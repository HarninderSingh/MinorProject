package com.harry.attendancetracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;


public class TutorLogin extends Fragment {
    FirebaseAuth mAuth;
    EditText etEmail, etPassword;
    Button btnLogin;
    TextView tvForgotPassword;
    String email,password;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tutor_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        etEmail = view.findViewById(R.id.inputEmail);
        etPassword = view.findViewById(R.id.inputPassword);
        tvForgotPassword = view.findViewById(R.id.fgtPswd);
        btnLogin = view.findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(view1 -> {
             email = etEmail.getText().toString().trim();
             password = etPassword.getText().toString().trim();
            if (password.isEmpty() && email.isEmpty())
                Toast.makeText(requireContext(), "Fill in credentials", Toast.LENGTH_SHORT).show();
            else
                signIn(email, password);
        });
        tvForgotPassword.setOnClickListener(view1 -> {
        });
    }

    private void signIn(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(requireActivity(), task -> {
                    if (task.isSuccessful()) {
                        // Sign in success, update UI with the signed-in user's information
                        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.cvHome, Menu.class, null).addToBackStack("SignUp").commit();

                    } else {
                        // If sign in fails, display a message to the user.
                        Toast.makeText(requireContext(), "Authentication Failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }


}