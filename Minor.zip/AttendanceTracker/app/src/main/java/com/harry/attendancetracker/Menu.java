package com.harry.attendancetracker;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class Menu extends Fragment {
    CardView cvAddStudent, cvRemoveStudent, cvViewStudent;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_menu, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        cvAddStudent = view.findViewById(R.id.cvAddStudent);
        cvViewStudent = view.findViewById(R.id.cvViewStudent);
        cvRemoveStudent = view.findViewById(R.id.cvRemoveStudent);
        cvAddStudent.setOnClickListener(view1 -> getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.cvHome, AddStudent.class, null).addToBackStack("Menu").commit());
        cvRemoveStudent.setOnClickListener(view12 -> getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.cvHome,RemoveStudent.class,null).addToBackStack("Menu").commit());
    }
}