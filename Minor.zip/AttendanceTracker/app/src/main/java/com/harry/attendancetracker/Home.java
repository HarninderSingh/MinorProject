package com.harry.attendancetracker;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class Home extends Fragment {
    TextView tvSignup;
    CardView cvTutor;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvSignup = view.findViewById(R.id.tvSignup);
        cvTutor = view.findViewById(R.id.cvTutor);
        cvTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.cvHome,TutorLogin.class,null).commit();
            }
        });
        tvSignup.setOnClickListener(view1 -> getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.cvHome, TutorSignUp.class,null).commit());
    }
}