package com.harry.attendancetracker;

public class PojoAdd {
    private String fatherName;
    private String name;
    private String contact;


    public String getFatherName() {
        return fatherName;
    }

    public PojoAdd(String name, String fatherName, String contact) {
        this.fatherName = fatherName;
        this.contact = contact;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getContact() {
        return contact;
    }

    public PojoAdd() {

    }
}
