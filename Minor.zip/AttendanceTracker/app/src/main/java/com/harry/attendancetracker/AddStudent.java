package com.harry.attendancetracker;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddStudent extends Fragment {
    EditText etName, etNumber, etFather;
    Button btnAdd;
    FirebaseDatabase database;
    DatabaseReference userReference;
    FirebaseAuth userAuthentication;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_student, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        etName = view.findViewById(R.id.inputName);
        etFather = view.findViewById(R.id.inputfather);
        etNumber = view.findViewById(R.id.inputNumber);
        btnAdd = view.findViewById(R.id.addStudent);
        database = FirebaseDatabase.getInstance();
        userAuthentication = FirebaseAuth.getInstance();
        userReference = database.getReference(userAuthentication.getCurrentUser().getUid());
        btnAdd.setOnClickListener(view1 -> {
            String name = etName.getText().toString();
            String father = etFather.getText().toString();
            String contact = etNumber.getText().toString();
            PojoAdd pojoAdd = new PojoAdd(name, father, contact);
            if (contact.length() == 10) {
                try {
                    userReference.child(name).setValue(pojoAdd).addOnSuccessListener(unused -> Toast.makeText(requireContext(), "Student Added", Toast.LENGTH_SHORT).show());
                } catch (Exception ex) {
                    Log.d("Error", ex.getMessage());
                }
            }
            else Toast.makeText(requireContext(), "Contact must be 10 digits", Toast.LENGTH_SHORT).show();
        });


    }
}